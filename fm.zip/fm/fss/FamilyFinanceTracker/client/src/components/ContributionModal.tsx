import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { web3Service } from "@/lib/web3";
import { useWallet } from "@/hooks/useWallet";
import { useToast } from "@/hooks/use-toast";
import { Goal } from "@/shared/schema";

interface ContributionModalProps {
  goal: Goal;
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
}

export function ContributionModal({ goal, isOpen, onClose, onSuccess }: ContributionModalProps) {
  const [amount, setAmount] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const { isConnected, connectWallet } = useWallet();

  const handleContribute = async () => {
    if (!isConnected || !web3Service.isConnected()) {
      toast({
        title: "Wallet not connected",
        description: "You must connect your wallet first",
        variant: "destructive"
      });

      // Try to connect wallet
      await connectWallet();
      return;
    }

    try {
      setIsLoading(true);
      //await web3Service.contributeToGoal(goal.contractGoalId, amount);
      toast({
        title: "Contribution Successful",
        description: "Thank you for your contribution!",
      });
      onSuccess();
      onClose();
    } catch (error: any) {
      console.error("Contribution failed:", error);
      toast({
        title: "Contribution Failed",
        description: error.message || "There was an error processing your contribution.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md mx-4 font-arabic">
        <DialogHeader>
          <DialogTitle className="text-xl font-bold text-gray-900">
            Contribute to Goal
          </DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div>
            <label className="text-sm font-medium text-gray-700">Goal Name</label>
            <p className="text-lg font-semibold">{goal.name}</p>
          </div>

          <div>
            <label className="text-sm font-medium text-gray-700">Current Progress</label>
            <p className="text-sm text-gray-600">
              {goal.savedAmount} / {goal.targetAmount} ETH ({Math.round((parseFloat(goal.savedAmount) / parseFloat(goal.targetAmount)) * 100)}%)
            </p>
          </div>

          {!isConnected ? (
            <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
              <p className="text-sm text-yellow-800 mb-3">
                Please connect your wallet to make a contribution
              </p>
              <Button
                onClick={connectWallet}
                className="w-full bg-primary hover:bg-primary-light text-white"
              >
                Connect Wallet
              </Button>
            </div>
          ) : (
            <>
              <div>
                <label htmlFor="amount" className="text-sm font-medium text-gray-700">
                  Contribution Amount (ETH)
                </label>
                <Input
                  id="amount"
                  type="number"
                  step="0.001"
                  min="0"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  placeholder="0.05"
                  className="mt-1"
                />
              </div>

              <div className="flex space-x-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setAmount("0.1")}
                >
                  0.1 ETH
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setAmount("0.5")}
                >
                  0.5 ETH
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setAmount("1.0")}
                >
                  1.0 ETH
                </Button>
              </div>

              <p className="text-xs text-blue-600">
                💡 The transaction will be executed via smart contract
              </p>

              <div className="flex space-x-3">
                <Button
                  onClick={handleContribute}
                  disabled={isLoading || !amount || parseFloat(amount) <= 0}
                  className="flex-1 bg-success hover:bg-success-dark text-white"
                >
                  {isLoading ? "Contributing..." : "💝 Confirm Contribution"}
                </Button>
                <Button variant="outline" onClick={onClose}>
                  Cancel
                </Button>
              </div>
            </>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}