import { ethers, BrowserProvider, Contract, formatEther, parseEther, formatUnits, parseUnits } from "ethers";
import { FAMILY_SAVER_ABI, CONTRACT_ADDRESS, NETWORKS, SUPPORTED_TOKENS, ERC20_ABI } from "./constants";

declare global {
  interface Window {
    ethereum?: any;
  }
}

export class Web3Service {
  private provider: BrowserProvider | null = null;
  private signer: ethers.JsonRpcSigner | null = null;
  private contract: Contract | null = null;
  private contractAddress: string;

  constructor(contractAddress: string = CONTRACT_ADDRESS) {
    // Contract address is immutable and cannot be changed
    this.contractAddress = CONTRACT_ADDRESS;
  }

  async connectWallet(): Promise<{ success: boolean; address?: string; error?: string }> {
    if (!window.ethereum) {
      return {
        success: false,
        error: "Please install MetaMask to continue"
      };
    }

    try {
      // Request account access
      const accounts = await window.ethereum.request({ method: 'eth_requestAccounts' });
      
      if (!accounts || accounts.length === 0) {
        return {
          success: false,
          error: "No accounts found. Please check your wallet."
        };
      }

      this.provider = new BrowserProvider(window.ethereum);
      this.signer = await this.provider.getSigner();

      const address = await this.signer.getAddress();

      // Check and switch to Web5Layer network
      const switchResult = await this.switchToWeb5Layer();
      if (!switchResult.success) {
        console.warn("Could not switch to Web5Layer network:", switchResult.error);
        // Still return success but with warning - let user know about network
        return {
          success: true,
          address,
          error: "Connected but please switch to Web5Layer network for full functionality"
        };
      }

      // Initialize contract
      try {
        this.contract = new Contract(
          this.contractAddress,
          FAMILY_SAVER_ABI,
          this.signer
        );
      } catch (contractError: any) {
        console.error("Failed to initialize contract:", contractError);
        // Still return success - contract issues shouldn't prevent wallet connection
        return {
          success: true,
          address,
          error: "Wallet connected but contract initialization failed. Check contract address."
        };
      }

      return {
        success: true,
        address
      };
    } catch (error: any) {
      console.error("Connect wallet error:", error);
      let errorMessage = "Failed to connect wallet";
      
      if (error.code === 4001) {
        errorMessage = "Wallet connection rejected by user";
      } else if (error.code === -32002) {
        errorMessage = "Wallet connection request already pending";
      } else if (error.message) {
        errorMessage = error.message;
      }
      
      return {
        success: false,
        error: errorMessage
      };
    }
  }

  async switchToWeb5Layer(): Promise<{ success: boolean; error?: string }> {
    if (!window.ethereum) {
      return { success: false, error: "MetaMask not available" };
    }

    try {
      const web5LayerConfig = NETWORKS.web5layer;

      // Try to switch to the network
      try {
        await window.ethereum.request({
          method: 'wallet_switchEthereumChain',
          params: [{ chainId: `0x${web5LayerConfig.chainId.toString(16)}` }],
        });
      } catch (switchError: any) {
        // This error code indicates that the chain has not been added to MetaMask.
        if (switchError.code === 4902) {
          try {
            await window.ethereum.request({
              method: 'wallet_addEthereumChain',
              params: [{
                chainId: `0x${web5LayerConfig.chainId.toString(16)}`,
                chainName: web5LayerConfig.name,
                rpcUrls: [web5LayerConfig.rpcUrl],
                blockExplorerUrls: web5LayerConfig.blockExplorer ? [web5LayerConfig.blockExplorer] : null,
                nativeCurrency: {
                  name: 'ETH',
                  symbol: 'ETH',
                  decimals: 18,
                },
              }],
            });
          } catch (addError: any) {
            console.error("Failed to add network:", addError);
            return { success: false, error: "Failed to add Web5Layer network to MetaMask." };
          }
        } else {
          console.error("Failed to switch network:", switchError);
          return { success: false, error: "Failed to switch to Web5Layer network." };
        }
      }

      return { success: true };
    } catch (error: any) {
      console.error("Error during network switch/add:", error);
      return { success: false, error: error.message };
    }
  }

  async getCurrentNetwork(): Promise<{ chainId: number; name: string }> {
    if (!this.provider) {
      throw new Error("Provider not initialized");
    }

    try {
      const network = await this.provider.getNetwork();
      const chainId = Number(network.chainId);
      const networkConfig = Object.values(NETWORKS).find(n => n.chainId === chainId);

      return {
        chainId,
        name: networkConfig?.name || `Unknown (${chainId})`
      };
    } catch (error: any) {
      console.error("Failed to get network:", error);
      return { chainId: 0, name: "Unknown" };
    }
  }

  async createGoal(name: string, targetAmount: string, durationInDays: number, tokenAddress: string = "0x0000000000000000000000000000000000000000"): Promise<{ success: boolean; transactionHash?: string; error?: string }> {
    console.log("web3Service.createGoal called with:", { name, targetAmount, durationInDays, tokenAddress });

    if (!this.contract) {
      console.error("Contract not initialized");
      return { success: false, error: "Smart contract not connected. Please connect your wallet and try again." };
    }

    if (!this.signer) {
      console.error("Signer not available");
      return { success: false, error: "Wallet not connected. Please connect your wallet and try again." };
    }

    try {
      // Check network first
      const network = await this.getCurrentNetwork();
      if (network.chainId !== 9000) {
        console.log("Wrong network, attempting to switch...");
        const switchResult = await this.switchToWeb5Layer();
        if (!switchResult.success) {
          return { success: false, error: "Please switch to Web5Layer network (Chain ID: 9000)" };
        }
        // Reinitialize contract with new network
        this.contract = new Contract(
          this.contractAddress,
          FAMILY_SAVER_ABI,
          this.signer
        );
      }

      // Validate inputs before sending transaction
      if (!name.trim()) {
        return { success: false, error: "Goal name cannot be empty" };
      }
      if (parseFloat(targetAmount) <= 0) {
        return { success: false, error: "Target amount must be greater than 0" };
      }
      if (durationInDays <= 0) {
        return { success: false, error: "Duration must be greater than 0 days" };
      }

      // Get token info for proper decimals
      const tokenInfo = Object.values(SUPPORTED_TOKENS).find(t => t.address.toLowerCase() === tokenAddress.toLowerCase()) 
        || SUPPORTED_TOKENS.ETH;

      console.log("Converting target amount to wei/units:", targetAmount, "for token:", tokenInfo.symbol);
      const targetWei = parseUnits(targetAmount, tokenInfo.decimals);
      console.log("Target units:", targetWei.toString());

      // Check wallet balance first
      try {
        const balance = await this.signer.provider.getBalance(await this.signer.getAddress());
        console.log("Wallet balance:", formatEther(balance), "ETH");
      } catch (balanceError: any) {
        console.warn("Could not get wallet balance:", balanceError);
      }

      // Check if contract exists by calling a view function first
      try {
        const goalCounter = await this.contract.goalCounter();
        console.log("Contract is accessible, goal counter:", goalCounter.toString());
      } catch (contractError: any) {
        console.error("Contract access error:", contractError);
        return {
          success: false,
          error: "Contract not found at this address. Please check if the contract is deployed correctly on Web5Layer."
        };
      }

      console.log("Sending transaction directly without gas estimation...");
      const tx = await this.contract.createGoal(name, targetWei, durationInDays, tokenAddress, {
        gasLimit: BigInt(500000), // Use fixed gas limit
        gasPrice: parseEther("0.000000020") // 20 gwei
      });

      console.log("Transaction sent, waiting for confirmation...", tx.hash);
      const receipt = await tx.wait();
      console.log("Transaction confirmed:", receipt);

      return {
        success: true,
        transactionHash: tx.hash
      };
    } catch (error: any) {
      console.error("Detailed error creating goal:", {
        error,
        message: error.message,
        reason: error.reason,
        code: error.code,
        data: error.data
      });

      let errorMessage = "Failed to create goal";

      if (error.code === "CALL_EXCEPTION" && error.message.includes("invalid opcode")) {
        errorMessage = "Contract incompatibility detected. The contract may need to be redeployed with correct Solidity compiler settings.";
      } else if (error.reason) {
        errorMessage = error.reason;
      } else if (error.data && error.data.message) {
        errorMessage = error.data.message;
      } else if (error.message) {
        if (error.message.includes("user rejected")) {
          errorMessage = "Transaction was rejected by user";
        } else if (error.message.includes("insufficient funds")) {
          errorMessage = "Insufficient funds for gas fees";
        } else if (error.message.includes("execution reverted")) {
          errorMessage = "Transaction failed - please check your inputs and network connection";
        } else if (error.message.includes("network")) {
          errorMessage = "Network error - please check your connection to Web5Layer";
        } else if (error.message.includes("missing revert data")) {
          errorMessage = "Contract error - please check if the contract is properly deployed and compatible";
        } else {
          errorMessage = error.message;
        }
      }

      console.log("Returning error:", errorMessage);

      return {
        success: false,
        error: errorMessage
      };
    }
  }

  async contribute(goalId: number, amount: string, tokenAddress?: string): Promise<{ success: boolean; transactionHash?: string; error?: string }> {
    if (!this.contract) {
      return { success: false, error: "Smart contract not connected" };
    }

    try {
      if (parseFloat(amount) <= 0) {
        return { success: false, error: "Contribution amount must be greater than 0" };
      }

      // Get goal details to determine token type
      const goalResult = await this.getGoalDetails(goalId);
      if (!goalResult.success || !goalResult.goal) {
        return { success: false, error: "Could not fetch goal details" };
      }

      const goalTokenAddress = goalResult.goal.tokenAddress || "0x0000000000000000000000000000000000000000";
      const tokenInfo = Object.values(SUPPORTED_TOKENS).find(t => 
        t.address.toLowerCase() === goalTokenAddress.toLowerCase()
      ) || SUPPORTED_TOKENS.ETH;

      const amountUnits = parseUnits(amount, tokenInfo.decimals);

      if (goalTokenAddress === "0x0000000000000000000000000000000000000000") {
        // ETH contribution
        try {
          const gasEstimate = await this.contract.contribute.estimateGas(goalId, 0, { value: amountUnits });
          const tx = await this.contract.contribute(goalId, 0, {
            value: amountUnits,
            gasLimit: gasEstimate + BigInt(50000)
          });
          await tx.wait();
          return { success: true, transactionHash: tx.hash };
        } catch (gasError: any) {
          console.error("Gas estimation failed:", gasError);
          return { success: false, error: "Gas estimation failed. Please try again." };
        }
      } else {
        // ERC20 token contribution
        try {
          // First approve the contract to spend tokens
          const tokenContract = new Contract(goalTokenAddress, [
            "function approve(address spender, uint256 amount) external returns (bool)",
            "function allowance(address owner, address spender) external view returns (uint256)"
          ], this.signer);

          // Check current allowance
          const currentAllowance = await tokenContract.allowance(await this.signer!.getAddress(), this.contractAddress);
          
          if (currentAllowance < amountUnits) {
            console.log("Approving token spending...");
            const approveTx = await tokenContract.approve(this.contractAddress, amountUnits);
            await approveTx.wait();
          }

          // Now contribute
          const gasEstimate = await this.contract.contribute.estimateGas(goalId, amountUnits);
          const tx = await this.contract.contribute(goalId, amountUnits, {
            gasLimit: gasEstimate + BigInt(50000)
          });
          await tx.wait();
          return { success: true, transactionHash: tx.hash };
        } catch (error: any) {
          console.error("Token contribution failed:", error);
          return { success: false, error: "Token contribution failed. Please ensure you have sufficient balance and try again." };
        }
      }
    } catch (error: any) {
      console.error("Error contributing:", error);

      let errorMessage = "Failed to contribute";

      if (error.reason) {
        errorMessage = error.reason;
      } else if (error.message) {
        if (error.message.includes("user rejected")) {
          errorMessage = "Transaction was rejected by user";
        } else if (error.message.includes("insufficient funds")) {
          errorMessage = "Insufficient funds for transaction";
        } else if (error.message.includes("Goal does not exist")) {
          errorMessage = "Goal does not exist";
        } else if (error.message.includes("Goal is not active")) {
          errorMessage = "Goal is no longer active";
        } else if (error.message.includes("Goal deadline has passed")) {
          errorMessage = "Goal deadline has passed";
        } else {
          errorMessage = error.message;
        }
      }

      return {
        success: false,
        error: errorMessage
      };
    }
  }

  async withdraw(goalId: number): Promise<{ success: boolean; transactionHash?: string; error?: string }> {
    if (!this.contract) {
      return { success: false, error: "Smart contract not connected" };
    }

    try {
      const tx = await this.contract.withdraw(goalId);
      await tx.wait();

      return {
        success: true,
        transactionHash: tx.hash
      };
    } catch (error: any) {
      return {
        success: false,
        error: error.message || "Failed to withdraw funds"
      };
    }
  }

  async getUserGoals(address: string): Promise<{ success: boolean; goalIds?: number[]; error?: string }> {
    if (!this.contract) {
      return { success: false, error: "Smart contract not connected" };
    }

    try {
      const goalIds = await this.contract.getUserGoals(address);
      return {
        success: true,
        goalIds: goalIds.map((id: bigint) => Number(id))
      };
    } catch (error: any) {
      return {
        success: false,
        error: error.message || "Failed to fetch goals"
      };
    }
  }

  async getGoalDetails(goalId: number): Promise<{ success: boolean; goal?: any; error?: string }> {
    if (!this.contract) {
      return { success: false, error: "Smart contract not connected" };
    }

    try {
      const goal = await this.contract.getGoal(goalId);
      const tokenAddress = goal.tokenAddress || "0x0000000000000000000000000000000000000000";
      const tokenInfo = Object.values(SUPPORTED_TOKENS).find(t => 
        t.address.toLowerCase() === tokenAddress.toLowerCase()
      ) || SUPPORTED_TOKENS.ETH;

      return {
        success: true,
        goal: {
          name: goal.name,
          targetAmount: formatUnits(goal.targetAmount, tokenInfo.decimals),
          savedAmount: formatUnits(goal.savedAmount, tokenInfo.decimals),
          deadline: goal.deadline,
          creator: goal.creator,
          isAchieved: goal.isAchieved,
          isActive: goal.isActive,
          createdAt: goal.createdAt,
          tokenAddress: tokenAddress,
          tokenInfo: tokenInfo
        }
      };
    } catch (error: any) {
      return {
        success: false,
        error: error.message || "Failed to fetch goal details"
      };
    }
  }

  async getGoal(goalId: number): Promise<{ success: boolean; goal?: any; error?: string }> {
    return this.getGoalDetails(goalId);
  }

  async getGoalContributions(goalId: number): Promise<{ success: boolean; contributions?: any[]; error?: string }> {
    if (!this.contract) {
      return { success: false, error: "Smart contract not connected" };
    }

    try {
      const contributions = await this.contract.getGoalContributions(goalId);
      return {
        success: true,
        contributions: contributions.map((contrib: any) => ({
          contributor: contrib.contributor,
          amount: formatEther(contrib.amount),
          timestamp: new Date(Number(contrib.timestamp) * 1000)
        }))
      };
    } catch (error: any) {
      return {
        success: false,
        error: error.message || "Failed to fetch contributions"
      };
    }
  }

  async getAddress(): Promise<string | null> {
    if (!this.signer) return null;
    try {
      return await this.signer.getAddress();
    } catch {
      return null;
    }
  }

  async getSupportedTokens(): Promise<{ success: boolean; tokens?: any[]; error?: string }> {
    if (!this.contract) {
      return { success: false, error: "Smart contract not connected" };
    }

    try {
      const result = await this.contract.getSupportedTokens();
      const tokens = result.addresses.map((address: string, index: number) => ({
        address,
        name: result.names[index],
        symbol: result.names[index], // You might want to get this from ERC20 contract
        decimals: result.decimals[index],
        icon: SUPPORTED_TOKENS.ETH.icon // Default icon, can be improved
      }));

      return { success: true, tokens };
    } catch (error: any) {
      return {
        success: false,
        error: error.message || "Failed to fetch supported tokens"
      };
    }
  }

  async getTokenBalance(tokenAddress: string, userAddress: string): Promise<{ success: boolean; balance?: string; error?: string }> {
    if (!this.signer) {
      return { success: false, error: "Wallet not connected" };
    }

    try {
      if (tokenAddress === "0x0000000000000000000000000000000000000000") {
        // ETH balance
        const balance = await this.signer.provider.getBalance(userAddress);
        return { success: true, balance: formatEther(balance) };
      } else {
        // ERC20 token balance
        const tokenContract = new Contract(tokenAddress, ERC20_ABI, this.signer);
        const balance = await tokenContract.balanceOf(userAddress);
        const decimals = await tokenContract.decimals();
        return { success: true, balance: formatUnits(balance, decimals) };
      }
    } catch (error: any) {
      return {
        success: false,
        error: error.message || "Failed to fetch token balance"
      };
    }
  }

  isConnected(): boolean {
    return this.provider !== null && this.signer !== null;
  }
}

export const web3Service = new Web3Service();